<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Concerns\ManagesMyTasks;
use App\Http\Controllers\Controller;
use App\Models\Task;
use Illuminate\Http\Request;

class MyTaskController extends Controller
{
    use ManagesMyTasks;

    private function companyId(): int
    {
        return auth()->user()->company_id;
    }

    public function index(Request $request, string $slug)
    {
        return view('my-tasks.index', array_merge(
            $this->myTasksIndexData($request),
            [
                'slug' => $slug,
                'ctx'  => [
                    'store'     => route('company.my-tasks.store', $slug),
                    'destroy'   => fn (Task $t) => route('company.my-tasks.destroy', [$slug, $t]),
                    'status'    => fn (int $id) => "/{$slug}/admin/my-tasks/{$id}/status",
                    'move'      => fn (int $id) => "/{$slug}/admin/my-tasks/{$id}/move",
                    'inline'    => fn (int $id) => "/{$slug}/admin/tasks/{$id}/inline",
                    'listUrl'   => route('company.my-tasks.index', $slug),
                    'canCreate' => true,
                    'canDeletePersonal' => true,
                ],
            ]
        ));
    }

    public function store(Request $request, string $slug)
    {
        $this->storeMyTask($request);
        return back()->with('success', 'Task created.');
    }

    public function updateStatus(Request $request, string $slug, Task $task)
    {
        $this->authorizeMine($task);
        $request->validate(['status' => 'required|in:todo,in_progress,in_review,done']);
        $task->update(['status' => $request->status]);
        return response()->json(['success' => true]);
    }

    public function move(Request $request, string $slug, Task $task)
    {
        $this->authorizeMine($task);
        $data = $request->validate([
            'group'    => 'required|in:recently,recent,overdue,today,upcoming,later,calendar',
            'due_date' => 'nullable|date',
        ]);
        $this->applyMyTaskMove($task, $data['group'], $data['due_date'] ?? null);
        return response()->json(['success' => true]);
    }

    public function destroy(string $slug, Task $task)
    {
        $this->authorizeMine($task);
        abort_if($task->created_by !== auth()->id() || $task->project_id !== null, 403);
        $task->delete();
        return back()->with('success', 'Task deleted.');
    }
}
